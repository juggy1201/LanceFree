import 'package:flutter/material.dart';

void main() => runApp(const LanceFreeApp());

const navy = Color(0xFF14213D);
const blue = Color(0xFF2563EB);
const green = Color(0xFF15966A);

class LanceFreeApp extends StatelessWidget {
  const LanceFreeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LanceFree',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F8FC),
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF7F8FC), foregroundColor: navy),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      home: const MainShell(),
    );
  }
}

class Job {
  final String title, company, category, type, description;
  final int pay;
  final String duration;
  const Job(this.title, this.company, this.category, this.type, this.pay, this.duration, this.description);
}

const jobs = <Job>[
  Job('Write product descriptions', 'BrightMart NG', 'Writing', 'Quick task', 12000, '1–2 days', 'Write clear descriptions for 20 everyday products. Good grammar and attention to detail are required.'),
  Job('Design a business flyer', 'Kola Foods', 'Design', 'Freelance', 25000, '3 days', 'Create a promotional flyer for a small food business. Include one revision after client feedback.'),
  Job('Enter survey responses', 'Insight Africa', 'Data entry', 'Quick task', 8000, '1 day', 'Organise supplied survey responses in a spreadsheet and check for missing entries.'),
  Job('Manage social media posts', 'Urban Threads', 'Marketing', 'Freelance', 60000, '2 weeks', 'Prepare and schedule social media content for a fashion brand.'),
  Job('Research local suppliers', 'MarketBridge', 'Research', 'Quick task', 15000, '2 days', 'Find and summarise publicly available information about local suppliers.'),
];

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;
  bool employerMode = false;
  final List<Job> applied = [];
  final List<Job> posted = [];

  void apply(Job job) {
    if (!applied.contains(job)) setState(() => applied.add(job));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Application saved in this demo.')));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(employerMode: employerMode, appliedCount: applied.length, onFind: () => setState(() => tab = 1), onPost: () => setState(() => tab = 2)),
      JobsPage(onApply: apply),
      PostJobPage(onPost: (job) { setState(() { posted.insert(0, job); tab = 0; }); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo job post created.'))); }),
      WalletPage(),
      ProfilePage(employerMode: employerMode, onModeChanged: (v) => setState(() => employerMode = v)),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(color: blue, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.work_outline, color: Colors.white, size: 20)), const SizedBox(width: 10), const Text('LanceFree', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -.4))]),
        actions: [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFFEAF1FF), borderRadius: BorderRadius.circular(20)), child: const Text('🇳🇬  NGN', style: TextStyle(color: blue, fontWeight: FontWeight.w700, fontSize: 12)))))],
      ),
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Find work'),
          NavigationDestination(icon: Icon(Icons.add_box_outlined), label: 'Post job'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Wallet'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final bool employerMode;
  final int appliedCount;
  final VoidCallback onFind, onPost;
  const HomePage({super.key, required this.employerMode, required this.appliedCount, required this.onFind, required this.onPost});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(gradient: const LinearGradient(colors: [navy, Color(0xFF2856A6)]), borderRadius: BorderRadius.circular(24)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(employerMode ? 'HIRE GREAT PEOPLE' : 'YOUR NEXT OPPORTUNITY', style: const TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1.4, fontWeight: FontWeight.bold)), const SizedBox(height: 10), Text(employerMode ? 'Find the right talent.' : 'Find work. Get paid.', style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w800)), const SizedBox(height: 8), Text(employerMode ? 'Post a job and connect with skilled freelancers.' : 'Discover freelance jobs and quick tasks from anywhere in Nigeria.', style: const TextStyle(color: Colors.white70, height: 1.4)), const SizedBox(height: 18), Wrap(spacing: 10, children: [FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: navy), onPressed: onFind, child: const Text('Explore jobs')), OutlinedButton(style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white70)), onPressed: onPost, child: const Text('Post a job'))])]),
    const SizedBox(height: 22), const Text('Your activity', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 12), Row(children: [Expanded(child: StatCard(label: 'Applications', value: '$appliedCount', icon: Icons.send_outlined)), const SizedBox(width: 12), const Expanded(child: StatCard(label: 'Demo earnings', value: '₦0', icon: Icons.payments_outlined))]), const SizedBox(height: 24), Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Popular opportunities', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: navy)), TextButton(onPressed: onFind, child: const Text('See all'))]), ...jobs.take(3).map((j) => JobTile(job: j, compact: true, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => JobDetailsPage(job: j, onApply: () {}))))),
  ]);
}

class StatCard extends StatelessWidget {
  final String label, value; final IconData icon;
  const StatCard({super.key, required this.label, required this.value, required this.icon});
  @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: blue), const SizedBox(height: 12), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: navy)), Text(label, style: const TextStyle(color: Colors.black54, fontSize: 12))]));
}

class JobsPage extends StatefulWidget {
  final ValueChanged<Job> onApply;
  const JobsPage({super.key, required this.onApply});
  @override State<JobsPage> createState() => _JobsPageState();
}
class _JobsPageState extends State<JobsPage> {
  String filter = 'All'; String search = '';
  @override Widget build(BuildContext context) {
    final visible = jobs.where((j) => (filter == 'All' || j.type == filter) && ('${j.title} ${j.company} ${j.category}'.toLowerCase().contains(search.toLowerCase()))).toList();
    return ListView(padding: const EdgeInsets.all(20), children: [const Text('Find your next job', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 6), const Text('Browse paid opportunities in Nigeria.', style: TextStyle(color: Colors.black54)), const SizedBox(height: 18), TextField(onChanged: (v) => setState(() => search = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search jobs or skills')), const SizedBox(height: 14), Wrap(spacing: 8, children: ['All', 'Freelance', 'Quick task'].map((f) => ChoiceChip(label: Text(f), selected: filter == f, onSelected: (_) => setState(() => filter = f))).toList()), const SizedBox(height: 12), ...visible.map((j) => JobTile(job: j, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => JobDetailsPage(job: j, onApply: () { widget.onApply(j); Navigator.pop(context); }))))), if (visible.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Center(child: Text('No matching jobs. Try another search.')))]);
  }
}

class JobTile extends StatelessWidget {
  final Job job; final VoidCallback onTap; final bool compact;
  const JobTile({super.key, required this.job, required this.onTap, this.compact = false});
  @override Widget build(BuildContext context) => Card(color: Colors.white, elevation: 0, margin: const EdgeInsets.only(bottom: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17)), child: InkWell(borderRadius: BorderRadius.circular(17), onTap: onTap, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(job.title, style: const TextStyle(fontWeight: FontWeight.w800, color: navy, fontSize: 15)), const SizedBox(height: 4), Text(job.company, style: const TextStyle(color: Colors.black54, fontSize: 12))])), Text('₦${job.pay}', style: const TextStyle(color: green, fontWeight: FontWeight.w800))]), const SizedBox(height: 12), Row(children: [Tag(job.category), const SizedBox(width: 7), Tag(job.type), const Spacer(), Text(job.duration, style: const TextStyle(color: Colors.black54, fontSize: 11))])]))));
}
class Tag extends StatelessWidget { final String text; const Tag(this.text, {super.key}); @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: const Color(0xFFF0F3FA), borderRadius: BorderRadius.circular(20)), child: Text(text, style: const TextStyle(fontSize: 10, color: navy, fontWeight: FontWeight.w600))); }

class JobDetailsPage extends StatelessWidget {
  final Job job; final VoidCallback onApply;
  const JobDetailsPage({super.key, required this.job, required this.onApply});
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Job details')), body: ListView(padding: const EdgeInsets.all(22), children: [Text(job.title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 8), Text(job.company, style: const TextStyle(color: Colors.black54)), const SizedBox(height: 18), Text('₦${job.pay}', style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: green)), const SizedBox(height: 14), Wrap(spacing: 8, children: [Tag(job.category), Tag(job.type), Tag(job.duration)]), const SizedBox(height: 26), const Text('About this task', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text(job.description, style: const TextStyle(height: 1.6)), const SizedBox(height: 28), FilledButton(onPressed: onApply, child: const Text('Apply for this job'))]));
}

class PostJobPage extends StatefulWidget {
  final ValueChanged<Job> onPost;
  const PostJobPage({super.key, required this.onPost});
  @override State<PostJobPage> createState() => _PostJobPageState();
}
class _PostJobPageState extends State<PostJobPage> {
  final title = TextEditingController(), company = TextEditingController(), amount = TextEditingController(), description = TextEditingController();
  String category = 'General'; String type = 'Freelance';
  @override void dispose() { title.dispose(); company.dispose(); amount.dispose(); description.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [const Text('Post an opportunity', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 6), const Text('Connect with people who can get the work done.', style: TextStyle(color: Colors.black54)), const SizedBox(height: 20), const Text('Job title'), const SizedBox(height: 7), TextField(controller: title, decoration: const InputDecoration(hintText: 'e.g. Create a business logo')), const SizedBox(height: 14), const Text('Business or client name'), const SizedBox(height: 7), TextField(controller: company, decoration: const InputDecoration(hintText: 'e.g. My Business')), const SizedBox(height: 14), const Text('Budget (NGN)'), const SizedBox(height: 7), TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(prefixText: '₦ ', hintText: '15000')), const SizedBox(height: 14), const Text('Category'), DropdownButtonFormField<String>(value: category, items: ['General','Writing','Design','Data entry','Marketing','Research','Technology'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => category = v ?? category)), const SizedBox(height: 14), const Text('Opportunity type'), DropdownButtonFormField<String>(value: type, items: ['Freelance','Quick task'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => type = v ?? type)), const SizedBox(height: 14), const Text('Description'), const SizedBox(height: 7), TextField(controller: description, maxLines: 4, decoration: const InputDecoration(hintText: 'Describe the work, deliverables and expectations...')), const SizedBox(height: 22), FilledButton(onPressed: () { final pay = int.tryParse(amount.text.trim()); if (title.text.trim().isEmpty || company.text.trim().isEmpty || description.text.trim().isEmpty || pay == null || pay <= 0) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please complete every field with a valid budget.'))); return; } widget.onPost(Job(title.text.trim(), company.text.trim(), category, type, pay, 'To be agreed', description.text.trim())); title.clear(); company.clear(); amount.clear(); description.clear(); }, child: const Text('Publish demo job'))]);
}

class WalletPage extends StatelessWidget {
  const WalletPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [const Text('My wallet', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 18), Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(22)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('DEMO AVAILABLE BALANCE', style: TextStyle(color: Colors.white70, letterSpacing: 1, fontSize: 11)), SizedBox(height: 10), Text('₦0.00', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 34)), SizedBox(height: 8), Text('This is a prototype balance, not withdrawable funds.', style: TextStyle(color: Colors.white70, fontSize: 12))])), const SizedBox(height: 20), const Text('Recent transactions', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)), const SizedBox(height: 10), const Card(color: Colors.white, elevation: 0, child: ListTile(leading: CircleAvatar(backgroundColor: Color(0xFFEAF1FF), child: Icon(Icons.info_outline, color: blue)), title: Text('No transactions yet'), subtitle: Text('Completed job payments will appear here.'))), const SizedBox(height: 12), const Text('Payment features will be enabled after secure payment-provider integration and account verification.', style: TextStyle(color: Colors.black54, height: 1.5))]);
}

class ProfilePage extends StatelessWidget {
  final bool employerMode; final ValueChanged<bool> onModeChanged;
  const ProfilePage({super.key, required this.employerMode, required this.onModeChanged});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [const Text('My profile', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: navy)), const SizedBox(height: 20), const CircleAvatar(radius: 36, backgroundColor: Color(0xFFEAF1FF), child: Icon(Icons.person, color: blue, size: 38)), const SizedBox(height: 12), const Center(child: Text('LanceFree demo user', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))), const Center(child: Text('Sign-in will be connected in the next stage', style: TextStyle(color: Colors.black54, fontSize: 12))), const SizedBox(height: 24), SwitchListTile(value: employerMode, onChanged: onModeChanged, title: const Text('Employer mode', style: TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(employerMode ? 'You are viewing employer tools.' : 'Switch on to focus on hiring and posting jobs.'), secondary: const Icon(Icons.business_center_outlined)), const Divider(), const ListTile(leading: Icon(Icons.verified_user_outlined), title: Text('Account verification'), subtitle: Text('Planned for the secure account setup stage')), const ListTile(leading: Icon(Icons.help_outline), title: Text('Help and support')), const ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('Privacy and terms'))]);
}
