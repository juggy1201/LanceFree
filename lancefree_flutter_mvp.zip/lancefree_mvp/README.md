# LanceFree Flutter MVP

A Flutter prototype for a Nigeria-first freelancing and paid-task marketplace. Currency display is NGN (₦).

## Included in this prototype
- Home dashboard and navigation
- Demo freelance and quick-task listings
- Search and category/type filters
- Job detail and demo application flow
- Job posting form with validation
- Demo wallet and profile screen
- Employer-mode toggle

## Run locally
1. Install Flutter SDK and set up Android Studio and/or Xcode.
2. In this directory run `flutter pub get`.
3. Run `flutter run` on an emulator or connected device.

## Important prototype limitations
This MVP uses in-memory sample data. It does not yet include real authentication, a backend, persistent job storage, chat, escrow, payment processing, withdrawals, or admin moderation. The displayed wallet balance is illustrative only. Do not collect real money or promise earnings using this prototype.

## Suggested next build stage
Connect Supabase Auth and PostgreSQL with role-based access (freelancer/employer/admin), then add job persistence, applications, messaging, and secure payment-provider integration after compliance and operational review.
